# App Locker (Android)

A native Android app that locks other apps behind a PIN or fingerprint. Built with
Kotlin + Jetpack Compose.

## How it works

- **Accessibility Service** (`AppLockAccessibilityService`) watches for foreground-app
  changes (`TYPE_WINDOW_STATE_CHANGED` events) and checks the changed package against
  your locked-apps list.
- If a locked app comes to the foreground and isn't in its "just unlocked" grace
  period, `LockActivity` is launched on top of it, showing a PIN pad (and a
  fingerprint option if enabled/available).
- The PIN is never stored in plain text — only a salted SHA-256 hash, inside
  `EncryptedSharedPreferences` (Android Keystore–backed).
- Locked-app selections and the unlock grace period are stored with Jetpack
  DataStore.
- Turning the screen off clears all "unlocked" grace periods, so every locked app
  requires re-authentication after the screen wakes up again.

## Project structure

```
app/src/main/java/com/example/applocker/
├── MainActivity.kt              # PIN setup gate + app list screen
├── LockActivity.kt              # Full-screen PIN/biometric prompt
├── AppLockerApplication.kt
├── service/AppLockAccessibilityService.kt
├── state/AppLockState.kt        # In-memory "currently unlocked" tracking
├── data/PinManager.kt           # Encrypted PIN storage
├── data/LockedAppsRepository.kt # DataStore-backed locked app set
├── data/InstalledAppsProvider.kt
├── model/AppInfo.kt
└── ui/
    ├── AppListScreen.kt
    ├── SetupPinScreen.kt
    └── LockScreen.kt
```

## Building it

1. Open the `AppLocker/` folder in **Android Studio** (Koala or newer recommended).
   Let Gradle sync — it will download AGP 8.5.2, Kotlin 1.9.24, and the listed
   AndroidX/Compose dependencies.
2. Change `applicationId` in `app/build.gradle.kts` if you want a different package
   name for publishing.
3. Run on a device or emulator (API 26+).

## First run / using the app

1. On first launch you'll be asked to create a 4–6 digit PIN (entered twice to
   confirm).
2. You'll see a banner asking you to enable the **Accessibility Service** — tap
   "Open Settings", find "App Locker" under installed services, and turn it on.
   This is what lets the app detect when a locked app is opened.
3. Toggle the switch next to any app in the list to lock it.
4. Open a locked app from your home screen — you should see the PIN/fingerprint
   prompt appear on top of it.
5. Use the settings (gear icon) to turn on fingerprint unlock or change your PIN.

## ⚠️ Before publishing to Google Play

This app relies on the **Accessibility Service** for a non-accessibility purpose
(detecting foreground app changes), which Google Play explicitly restricts:

- You must fill out the **Accessibility API Declaration Form** in Play Console and
  clearly explain the app-locking use case.
- Your store listing and in-app onboarding should clearly disclose *why* you need
  the permission before the user grants it (the current banner text is a starting
  point, but expand on it for a real submission).
- Apps that request Accessibility access without a clear, disclosed, core-to-the-app
  reason are commonly rejected or removed — this is one of Play's most
  actively-enforced policies, so budget time for review back-and-forth.
- Consider linking a privacy policy, since you're technically processing sensitive
  usage data (which apps the user opens).

## Known limitations / ideas for v2

- A determined user can still bypass the lock via the Recents/multitasking screen
  in some edge cases before the accessibility event fires — consider adding a
  "cover Recents thumbnail" feature (`FLAG_SECURE`-style) for locked apps.
- No "prevent uninstall without PIN" protection yet — this would require a Device
  Admin or Device Owner policy.
- No app-usage timer/limits — could be added alongside the existing lock feature.
- Pattern-lock (in addition to PIN/fingerprint) isn't implemented.

## Not built/tested here

This sandbox doesn't have the Android SDK or network access, so the project
wasn't compiled or run — only written and reviewed for correctness. Do a build
in Android Studio as your first step, and let me know if anything doesn't
compile so I can fix it.
