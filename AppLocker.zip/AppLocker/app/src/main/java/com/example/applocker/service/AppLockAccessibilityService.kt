package com.example.applocker.service

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.view.accessibility.AccessibilityEvent
import com.example.applocker.LockActivity
import com.example.applocker.data.LockedAppsRepository
import com.example.applocker.state.AppLockState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class AppLockAccessibilityService : AccessibilityService() {

    private val serviceJob = Job()
    private val serviceScope = CoroutineScope(Dispatchers.Default + serviceJob)

    @Volatile private var lockedPackages: Set<String> = emptySet()

    private val screenOffReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            // Require re-authentication any time the screen turns off.
            AppLockState.clearAll()
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        val repository = LockedAppsRepository(applicationContext)
        serviceScope.launch {
            repository.lockedPackages.collect { lockedPackages = it }
        }
        registerReceiver(screenOffReceiver, IntentFilter(Intent.ACTION_SCREEN_OFF))
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val packageName = event.packageName?.toString() ?: return
        if (packageName == applicationContext.packageName) return
        if (packageName == "com.android.systemui") return

        if (packageName !in lockedPackages) {
            if (AppLockState.pendingLockPackage != null && packageName != AppLockState.pendingLockPackage) {
                AppLockState.pendingLockPackage = null
            }
            return
        }

        if (AppLockState.isUnlocked(packageName)) return
        if (AppLockState.pendingLockPackage == packageName) return

        AppLockState.pendingLockPackage = packageName
        val lockIntent = Intent(this, LockActivity::class.java).apply {
            putExtra(LockActivity.EXTRA_PACKAGE_NAME, packageName)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        startActivity(lockIntent)
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        runCatching { unregisterReceiver(screenOffReceiver) }
        serviceJob.cancel()
    }
}
