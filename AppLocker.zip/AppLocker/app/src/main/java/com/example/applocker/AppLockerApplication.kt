package com.example.applocker

import android.app.Application

class AppLockerApplication : Application()
