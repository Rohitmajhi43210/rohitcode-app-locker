package com.example.applocker

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.example.applocker.data.LockedAppsRepository
import com.example.applocker.data.PinManager
import com.example.applocker.state.AppLockState
import com.example.applocker.ui.LockScreen
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class LockActivity : ComponentActivity() {

    private lateinit var pinManager: PinManager
    private lateinit var repository: LockedAppsRepository
    private var targetPackage: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        targetPackage = intent.getStringExtra(EXTRA_PACKAGE_NAME) ?: run {
            finish()
            return
        }
        pinManager = PinManager(this)
        repository = LockedAppsRepository(this)

        setContent {
            LockScreen(
                appLabel = appLabelFor(targetPackage),
                biometricAvailable = biometricAvailable(),
                onPinSubmit = { pin -> handlePinSubmit(pin) },
                onBiometricRequested = { showBiometricPrompt() },
                onCancel = { goHome() }
            )
        }

        if (pinManager.isBiometricEnabled() && biometricAvailable()) {
            showBiometricPrompt()
        }
    }

    private fun appLabelFor(packageName: String): String = try {
        val pm = packageManager
        pm.getApplicationLabel(pm.getApplicationInfo(packageName, 0)).toString()
    } catch (e: Exception) {
        packageName
    }

    private fun biometricAvailable(): Boolean {
        val manager = BiometricManager.from(this)
        return manager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) ==
            BiometricManager.BIOMETRIC_SUCCESS
    }

    private fun showBiometricPrompt() {
        val executor = ContextCompat.getMainExecutor(this)
        val prompt = BiometricPrompt(
            this,
            executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    unlockAndFinish()
                }
            }
        )
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(getString(R.string.unlock_title))
            .setSubtitle(appLabelFor(targetPackage))
            .setNegativeButtonText(getString(R.string.use_pin))
            .build()
        prompt.authenticate(info)
    }

    private fun handlePinSubmit(pin: String): Boolean {
        val correct = pinManager.verifyPin(pin)
        if (correct) unlockAndFinish()
        return correct
    }

    private fun unlockAndFinish() {
        lifecycleScope.launch {
            val graceSeconds = repository.gracePeriodSeconds.first()
            AppLockState.markUnlocked(targetPackage, graceSeconds * 1000L)
            AppLockState.pendingLockPackage = null
            finish()
        }
    }

    private fun goHome() {
        AppLockState.pendingLockPackage = null
        val homeIntent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_HOME)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        startActivity(homeIntent)
        finish()
    }

    @Deprecated("Deprecated in Java", ReplaceWith("onBackPressedDispatcher"))
    override fun onBackPressed() {
        // Don't allow back-press to simply reveal the locked app underneath.
        goHome()
    }

    companion object {
        const val EXTRA_PACKAGE_NAME = "extra_package_name"
    }
}
