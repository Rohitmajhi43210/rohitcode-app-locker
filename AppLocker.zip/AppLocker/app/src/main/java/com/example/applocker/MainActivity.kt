package com.example.applocker

import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.example.applocker.data.InstalledAppsProvider
import com.example.applocker.data.LockedAppsRepository
import com.example.applocker.data.PinManager
import com.example.applocker.service.AppLockAccessibilityService
import com.example.applocker.ui.AppListScreen
import com.example.applocker.ui.SetupPinScreen
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var pinManager: PinManager
    private lateinit var repository: LockedAppsRepository
    private val resumeTrigger = mutableStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pinManager = PinManager(this)
        repository = LockedAppsRepository(this)

        setContent {
            var pinIsSet by remember { mutableStateOf(pinManager.isPinSet()) }
            var biometricEnabled by remember { mutableStateOf(pinManager.isBiometricEnabled()) }
            val trigger by resumeTrigger
            val accessibilityEnabled = remember(trigger) { isAccessibilityServiceEnabled() }

            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    if (!pinIsSet) {
                        SetupPinScreen(
                            onPinCreated = { pin ->
                                pinManager.setPin(pin)
                                pinIsSet = true
                            }
                        )
                    } else {
                        val apps = remember { InstalledAppsProvider.getLaunchableApps(this@MainActivity) }
                        val lockedPackages by repository.lockedPackages.collectAsState(initial = emptySet())
                        val scope = rememberCoroutineScope()

                        AppListScreen(
                            apps = apps,
                            lockedPackages = lockedPackages,
                            accessibilityEnabled = accessibilityEnabled,
                            biometricEnabled = biometricEnabled,
                            onToggleLocked = { pkg, locked ->
                                scope.launch { repository.setLocked(pkg, locked) }
                            },
                            onOpenAccessibilitySettings = {
                                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                            },
                            onToggleBiometric = { enabled ->
                                pinManager.setBiometricEnabled(enabled)
                                biometricEnabled = enabled
                            },
                            onResetPin = { pinManager.setPin(it) }
                        )
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Re-check accessibility permission state in case the user just returned from Settings.
        resumeTrigger.value++
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val expectedComponent = ComponentName(this, AppLockAccessibilityService::class.java)
        val enabledServices = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabledServices.split(':').any {
            it.equals(expectedComponent.flattenToString(), ignoreCase = true)
        }
    }
}
