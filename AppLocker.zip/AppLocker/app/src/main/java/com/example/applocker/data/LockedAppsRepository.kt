package com.example.applocker.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "app_locker_settings")

class LockedAppsRepository(private val context: Context) {

    private object Keys {
        val LOCKED_PACKAGES = stringSetPreferencesKey("locked_packages")
        val GRACE_PERIOD_SECONDS = intPreferencesKey("grace_period_seconds")
    }

    val lockedPackages: Flow<Set<String>> = context.dataStore.data.map {
        it[Keys.LOCKED_PACKAGES] ?: emptySet()
    }

    /** How long an app stays unlocked after a correct PIN/biometric before it re-locks. */
    val gracePeriodSeconds: Flow<Int> = context.dataStore.data.map {
        it[Keys.GRACE_PERIOD_SECONDS] ?: 30
    }

    suspend fun setLocked(packageName: String, locked: Boolean) {
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.LOCKED_PACKAGES]?.toMutableSet() ?: mutableSetOf()
            if (locked) current.add(packageName) else current.remove(packageName)
            prefs[Keys.LOCKED_PACKAGES] = current
        }
    }

    suspend fun setGracePeriodSeconds(seconds: Int) {
        context.dataStore.edit { it[Keys.GRACE_PERIOD_SECONDS] = seconds }
    }
}
