package com.example.applocker.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun LockScreen(
    appLabel: String,
    biometricAvailable: Boolean,
    onPinSubmit: (String) -> Boolean,
    onBiometricRequested: () -> Unit,
    onCancel: () -> Unit
) {
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }
    val maxPinLength = 6

    MaterialTheme {
        Surface(modifier = Modifier.fillMaxSize()) {
            Column(
                modifier = Modifier.fillMaxSize().padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(Icons.Filled.Fingerprint, contentDescription = null, modifier = Modifier.size(48.dp))
                Spacer(Modifier.height(16.dp))
                Text(appLabel, fontSize = 20.sp, fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(8.dp))
                Text(if (error) "Wrong PIN, try again" else "Enter PIN to unlock")
                Spacer(Modifier.height(24.dp))

                Row {
                    repeat(pin.length.coerceAtMost(maxPinLength)) {
                        Box(
                            Modifier.padding(6.dp).size(14.dp).clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary)
                        )
                    }
                    repeat((maxPinLength - pin.length).coerceAtLeast(0)) {
                        Box(
                            Modifier.padding(6.dp).size(14.dp).clip(CircleShape)
                                .background(MaterialTheme.colorScheme.outlineVariant)
                        )
                    }
                }

                Spacer(Modifier.height(32.dp))

                val rows = listOf(
                    listOf("1", "2", "3"),
                    listOf("4", "5", "6"),
                    listOf("7", "8", "9"),
                    listOf(if (biometricAvailable) "bio" else "", "0", "del")
                )

                rows.forEach { row ->
                    Row(horizontalArrangement = Arrangement.Center) {
                        row.forEach { key ->
                            Box(
                                modifier = Modifier.padding(8.dp).size(64.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                when (key) {
                                    "" -> {}
                                    "del" -> IconButton(onClick = {
                                        if (pin.isNotEmpty()) pin = pin.dropLast(1)
                                        error = false
                                    }) {
                                        Icon(Icons.Filled.Backspace, contentDescription = "Delete")
                                    }
                                    "bio" -> IconButton(onClick = onBiometricRequested) {
                                        Icon(Icons.Filled.Fingerprint, contentDescription = "Use biometric")
                                    }
                                    else -> TextButton(onClick = {
                                        if (pin.length < maxPinLength) {
                                            pin += key
                                            error = false
                                        }
                                    }) {
                                        Text(key, fontSize = 24.sp)
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(Modifier.height(16.dp))
                Button(
                    onClick = {
                        val success = onPinSubmit(pin)
                        if (!success) {
                            error = true
                            pin = ""
                        }
                    },
                    enabled = pin.length in 4..maxPinLength
                ) {
                    Text("Unlock")
                }

                Spacer(Modifier.height(8.dp))
                TextButton(onClick = onCancel) {
                    Text("Cancel")
                }
            }
        }
    }
}
