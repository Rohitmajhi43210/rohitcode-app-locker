package com.example.applocker.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import com.example.applocker.model.AppInfo

@Composable
fun AppListScreen(
    apps: List<AppInfo>,
    lockedPackages: Set<String>,
    accessibilityEnabled: Boolean,
    biometricEnabled: Boolean,
    onToggleLocked: (String, Boolean) -> Unit,
    onOpenAccessibilitySettings: () -> Unit,
    onToggleBiometric: (Boolean) -> Unit,
    onResetPin: (String) -> Unit
) {
    var showSettings by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("App Locker") },
                actions = {
                    IconButton(onClick = { showSettings = true }) {
                        Icon(Icons.Filled.Settings, contentDescription = "Settings")
                    }
                }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding)) {
            if (!accessibilityEnabled) {
                Card(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Accessibility permission required", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(4.dp))
                        Text("App Locker needs the Accessibility Service enabled to detect when a locked app is opened.")
                        Spacer(Modifier.height(8.dp))
                        Button(onClick = onOpenAccessibilitySettings) {
                            Text("Open Settings")
                        }
                    }
                }
            }

            LazyColumn {
                items(apps, key = { it.packageName }) { app ->
                    ListItem(
                        headlineContent = { Text(app.label) },
                        supportingContent = { Text(app.packageName, style = MaterialTheme.typography.bodySmall) },
                        leadingContent = {
                            app.icon?.let { drawable ->
                                val bitmap = remember(app.packageName) { drawable.toBitmap(96, 96) }
                                Image(
                                    bitmap = bitmap.asImageBitmap(),
                                    contentDescription = null,
                                    modifier = Modifier.size(40.dp)
                                )
                            }
                        },
                        trailingContent = {
                            Switch(
                                checked = app.packageName in lockedPackages,
                                onCheckedChange = { checked -> onToggleLocked(app.packageName, checked) }
                            )
                        }
                    )
                    HorizontalDivider()
                }
            }
        }
    }

    if (showSettings) {
        SettingsDialog(
            biometricEnabled = biometricEnabled,
            onDismiss = { showSettings = false },
            onToggleBiometric = onToggleBiometric,
            onResetPin = onResetPin
        )
    }
}

@Composable
private fun SettingsDialog(
    biometricEnabled: Boolean,
    onDismiss: () -> Unit,
    onToggleBiometric: (Boolean) -> Unit,
    onResetPin: (String) -> Unit
) {
    var newPin by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Settings") },
        text = {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Use fingerprint to unlock", Modifier.weight(1f))
                    Switch(checked = biometricEnabled, onCheckedChange = onToggleBiometric)
                }
                Spacer(Modifier.height(16.dp))
                Text("Change PIN")
                OutlinedTextField(
                    value = newPin,
                    onValueChange = { if (it.length <= 6) newPin = it.filter(Char::isDigit) },
                    label = { Text("New PIN (4-6 digits)") }
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (newPin.length in 4..6) {
                    onResetPin(newPin)
                    newPin = ""
                }
                onDismiss()
            }) { Text("Save") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        }
    )
}
