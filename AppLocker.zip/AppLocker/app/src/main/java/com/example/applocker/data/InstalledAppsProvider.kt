package com.example.applocker.data

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import com.example.applocker.model.AppInfo

/**
 * Lists only apps that expose a launcher icon (i.e. the ones a user could actually
 * open and might want to lock). This intentionally avoids getInstalledApplications()
 * / QUERY_ALL_PACKAGES, which Play Store restricts for apps like this one.
 */
object InstalledAppsProvider {

    fun getLaunchableApps(context: Context): List<AppInfo> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolveInfos = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
        val ownPackage = context.packageName

        return resolveInfos.asSequence()
            .map { it.activityInfo }
            .filter { it.packageName != ownPackage }
            .distinctBy { it.packageName }
            .map { activityInfo ->
                AppInfo(
                    packageName = activityInfo.packageName,
                    label = activityInfo.loadLabel(pm).toString(),
                    icon = activityInfo.loadIcon(pm)
                )
            }
            .sortedBy { it.label.lowercase() }
            .toList()
    }
}
