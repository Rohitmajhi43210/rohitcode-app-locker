package com.example.applocker.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp

@Composable
fun SetupPinScreen(onPinCreated: (String) -> Unit) {
    var step by remember { mutableStateOf(0) } // 0 = enter, 1 = confirm
    var firstPin by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            if (step == 0) "Create a PIN to lock your apps" else "Confirm your PIN",
            style = MaterialTheme.typography.titleLarge
        )
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(
            value = pin,
            onValueChange = { if (it.length <= 6) pin = it.filter(Char::isDigit) },
            label = { Text("4-6 digit PIN") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            visualTransformation = PasswordVisualTransformation()
        )
        error?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, color = MaterialTheme.colorScheme.error)
        }
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = {
                if (pin.length < 4) {
                    error = "PIN must be at least 4 digits"
                    return@Button
                }
                if (step == 0) {
                    firstPin = pin
                    pin = ""
                    step = 1
                    error = null
                } else {
                    if (pin == firstPin) {
                        onPinCreated(pin)
                    } else {
                        error = "PINs don't match, try again"
                        pin = ""
                        firstPin = ""
                        step = 0
                    }
                }
            }
        ) {
            Text(if (step == 0) "Next" else "Confirm")
        }
    }
}
