package com.example.applocker.state

import android.os.SystemClock

/**
 * In-process, in-memory record of which locked apps are currently "unlocked" for a
 * short grace period, and which package (if any) has a lock screen pending. This is
 * intentionally not persisted - a process restart or screen-off should require
 * re-authentication.
 */
object AppLockState {

    // packageName -> elapsed-realtime timestamp (ms) until which the app stays unlocked
    private val unlockedUntil = mutableMapOf<String, Long>()

    // The package currently showing (or about to show) the lock screen, to avoid
    // re-triggering the accessibility service while it's already up.
    @Volatile
    var pendingLockPackage: String? = null

    fun isUnlocked(packageName: String): Boolean {
        val until = unlockedUntil[packageName] ?: return false
        return SystemClock.elapsedRealtime() < until
    }

    fun markUnlocked(packageName: String, graceMillis: Long) {
        unlockedUntil[packageName] = SystemClock.elapsedRealtime() + graceMillis
    }

    fun clearAll() {
        unlockedUntil.clear()
        pendingLockPackage = null
    }
}
