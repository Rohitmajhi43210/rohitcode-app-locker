# Add project specific ProGuard rules here.
# Not enabled by default (isMinifyEnabled = false in build.gradle.kts).
